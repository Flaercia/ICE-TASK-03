public interface iStaff {
         int getStaffNumber();
         String getStaffLocation();
         String getStaffHiringProcess();
    }

