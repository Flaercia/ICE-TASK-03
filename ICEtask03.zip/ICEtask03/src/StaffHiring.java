
public class StaffHiring extends Staff {

    // Constructor: receives the staff number and location, and passes them to the parent class using 'super'.
    public StaffHiring(int staffNumber, String staffLocation) {
        super(staffNumber, staffLocation);
    }

    // This method overrides the one in the parent class to return a custom report for staff hiring.
    @Override
    public String getStaffHiringProcess() {
        String report = "\nSTAFF HIRING REPORT\n***************************************\n";
        // Adds the location of the hiring process
        report += "LOCATION: " + staffLocation + "\n";
        // Adds the current number of staff
        report += "STAFF NUMBER: " + staffNumber + "\n";
        // Decision logic: if the staff number is below 20, new staff can be hired
        report += "HIRE STAFF: " + (staffNumber < 20 ? "YES" : "NO");
        return report;
    }
}