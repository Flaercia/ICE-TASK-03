import java.util.Scanner;

public class UseStaff {
    public static void main(String[] args) {
        // Create a Scanner object to read user input from the console
        Scanner scanner = new Scanner(System.in);

        // Ask the user to input the current staff number
        System.out.print("Enter the current staff number: ");
        int staffNumber = scanner.nextInt();

        // Clear the input buffer before reading a string
        // This is necessary because nextInt() does not consume the newline character
        scanner.nextLine();

        // Ask the user to input the location where the staff is being hired
        System.out.print("Enter the staff hiring location: ");
        String location = scanner.nextLine(); // Now this will read correctly after nextInt

        // Create a StaffHiring object using the entered staff number and location
        StaffHiring staff1 = new StaffHiring(staffNumber, location);

        // Display the hiring process information
        System.out.println(staff1.getStaffHiringProcess());
    }
}
